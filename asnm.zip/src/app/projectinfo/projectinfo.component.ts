import { Component, OnInit } from '@angular/core';
import { ProjectServiceService } from '../service/project-service.service';

@Component({
  selector: 'app-projectinfo',
  templateUrl: './projectinfo.component.html',
  styleUrls: ['./projectinfo.component.css']
})
export class ProjectinfoComponent implements OnInit {
addrow=false
selectedrow:any
  public projects:any;
  selected:any;
  constructor(private proService:ProjectServiceService) { }
public addrowfun(){
  this.addrow=true;
}
public editdata(id:any){
  this.proService.getProjects().subscribe((res:any)=>{
    res.filter((item:any)=>{

      if(item.projectId == id)
      this.addrow=true;
        this.selectedrow=item;
        console.log(this.selectedrow);
    })
      
  })
//   this.selectedrow =this.projects.map((x:any)=>{
// if(x.projectId==id){
//   console.log(x)
//   this.addrow=true;
//   return x;
// }


// })
}
  ngOnInit(): void {
    this.proService.getProjects().subscribe( res=>this.projects=res)
    console.log(this.selectedrow)
  }

  selectAll(event:any) {
    if (event.target.checked) {
        this.projects = this.projects.map((row:any) => {
           row.selected = true;
           return row;
        });
    } else {
        this.projects = this.projects.map((row:any) => {
           row.selected = false;
           return row;
        });
    }
}

}
